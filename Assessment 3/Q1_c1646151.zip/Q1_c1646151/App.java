/*
 * Name: Charles Read
 * Student Number: c1646151
 */

import java.io.*;
import java.util.Scanner;
public class App {
    public static void main(String[] args) {

        scanner i = new scanner(); //new scanner from scanner class.

        System.out.println();
        System.out.println(" --Student Entries Program--"); 
        System.out.println("___________________________________");
        System.out.println(" 1.  Add new Entry");
        System.out.println(" 2.  Search Data");
        System.out.println(" 3.  View Data");
        System.out.println(" 4.  Delete Entry");
        System.out.println(" 5.  Quit Program");
        System.out.println("___________________________________");
        System.out.println();

        //uses scanner class to take user input.
        String menuOption = i.readInput(" Please enter the number that corresponds to your option: "); 


         if (menuOption.matches("1")) { //option 1 is adding an entry.
            System.out.println();
            String studentName = i.readInput(" Please enter student name: ");
            if (studentName.matches("[a-zA-Z]+(\\s+[a-zA-Z]+)*")) { //Regualr expression validate inputs.
                    String studentTemp = studentName;
                    String studentNum = i.readInput(" Please enter student number: ");

                if (studentNum.matches("[C]{1}[0-9]{6}")) { 
                    String courseName = i.readInput(" Please enter course name: ");

                    if (courseName.matches("[a-zA-Z]+(\\s+[a-zA-Z]+)*")) { 
                         String courseID = i.readInput(" Please enter course ID: ");

                         if (courseID.matches("[A-Z]{2}[0-9]{4}")) { 
                            String houseNum = i.readInput(" Please enter house number: ");

                            if (houseNum.matches("\\d+[a-zA-Z]") || houseNum.matches("[0-9]*")) { 
                                String streetName = i.readInput(" Please enter a street name: ");

                                if (streetName.matches("[a-zA-Z]+(\\s+[a-zA-Z]+)*")) { 
                                    String townName = i.readInput(" Please enter a town name: ");

                                    if (townName.matches("[a-zA-Z]+(\\s+[a-zA-Z]+)*")) { 
                                    String postcode = i.readInput(" Please enter a postcode: ");

                                        if (postcode.matches("[A-Z]{2}[0-9]{1}[A-Z]{2}")) { 
                                            menuFunc temp = new menuFunc();
                                            temp.add(studentNum, studentTemp, courseID, courseName, houseNum, streetName, townName, postcode); //calls add function.
                                            System.out.println();
                                            System.out.println(" This entry can be saved in a .txt or .bin file.");

                                            String file = i.readInput(" Please enter the file this entry shall be stored in: ");

                                            System.out.println("___________________________________");
                                            System.out.println();
                                            System.out.println(" The student entry has now been created.");

                                            temp.Write(file); 

                                            System.out.println("___________________________________");
                                            System.out.println(" Program has been quit.");
                                        } 
                                    } 
                            //else messages for formatting errors.
                            else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");;
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                            } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");
                            }


        } else if (menuOption.matches("2")) { //option 2 is searching entries.

        System.out.println("___________________________________");
        System.out.println(" Only txt or bin files can be searched.");
        String searchData = i.readInput(" Please enter the file that will be searched: ");
        System.out.println("___________________________________");
        System.out.println();
        System.out.println(" 1.  Search by Course Name");
        System.out.println(" 2.  Search by Address");
        System.out.println(" 3.  Search by Position");
        System.out.println("___________________________________");

        System.out.println();
        String searchOption = i.readInput(" Please enter the number that corresponds to your method of search: ");
        System.out.println("___________________________________");
        System.out.println();

            if (searchOption.matches("1")) { //Search option 1 is to search with couseName.
                String courseInput = i.readInput(" Please enter the course name: ");
                System.out.println("___________________________________");
                System.out.println();

                searchFunc temp = new searchFunc();
                temp.courseSearch(searchData, courseInput); //calls SearchCourse function.

                System.out.println();
                System.out.println(" Results empty if no none found. ");
                System.out.println("___________________________________");
                System.out.println(" Program has ended.");
                System.out.println();
            } 
            
            else if (searchOption.matches("2")) { //Search option 2 is to search with address substring.
                System.out.println(" House numbers, street names, towns or postcodes are accepted.");
                String addressString = i.readInput(" Please enter one of these substrings: ");
                System.out.println("___________________________________");
                System.out.println();

                searchFunc temp = new searchFunc();
                temp.addressSearch(searchData, addressString); //calls addressSearch function.

                System.out.println();
                System.out.println(" Results empty if no none found. ");
                System.out.println("___________________________________");
                System.out.println(" Program has ended.");
                System.out.println();
           } 

           else if (searchOption.matches("3")) { //Search option 3 is to search in a range.
                System.out.println();
                String rangeStart = i.readInput(" Please enter the first position in your range: ");
                if (rangeStart.matches("[0-9]+")) { 
                    int startInt = Integer.parseInt(rangeStart); //string into integer conversion for logic.
                    if (startInt > 0) {
                        String rangeEnd = i.readInput(" Please enter the last position in your range: ");
                        if (rangeEnd.matches("[0-9]+")) { 
                            int endInt = Integer.parseInt(rangeEnd); //string into integer conversion for logic.
                            if (endInt >= startInt) {
                                System.out.println();
                                System.out.println("___________________________________");
                                System.out.println();

                                searchFunc temp = new searchFunc ();
                                temp.viewRange(searchData, startInt, endInt); //calls viewEnteries function

                                System.out.println();
                                System.out.println(" Results empty if no none found. ");
                                System.out.println();
                                System.out.println("___________________________________");
                                System.out.println(" Program has ended.");

                            } else {
                                System.out.println("___________________________________");
                                System.out.println(" Formatting error, please try again.");}
                        } else {
                            System.out.println("___________________________________");
                            System.out.println(" Formatting error, please try again.");}
                    } else {
                        System.out.println("___________________________________");
                        System.out.println(" Formatting error, please try again.");}
                } else {
                    System.out.println("___________________________________");
                    System.out.println(" Formatting error, please try again.");}
            } else {
            System.out.println("___________________________________");
            System.out.println(" Formatting error, please try again.");}
        } 



        else if (menuOption.matches("3")) { //menu option 3 is to view student entries.
            System.out.println();
            System.out.println(" Only txt or bin files can be displayed.");
            String file = i.readInput(" Please enter the file that will be displayed: ");
            
            System.out.println("___________________________________");
            System.out.println();

            menuFunc temp = new menuFunc();

            temp.Read(file); //calls the read function
            System.out.println("___________________________________");
            System.out.println(" Program has now ended.");
        } 


        else if (menuOption.matches("4")) { //menu option 4 is to delete student entry.
            System.out.println();
            System.out.println(" Only txt or bin files can be edited.");
            String file = i.readInput(" Please enter the file that will be edited: ");
            System.out.println("___________________________________");
            System.out.println();

            String entryPosition = i.readInput(" Please enter the student's position as an integer. ");
            if (entryPosition.matches("[0-9]+")) {
                int stuPosition = Integer.parseInt(entryPosition);

                if (stuPosition > 0) {
                    menuFunc temp = new menuFunc();
                    temp.deleteEntry(file, stuPosition); //calls Delete function.

                    System.out.println("___________________________________");
                    System.out.println();
                    System.out.println(" Student has been deleted.");
                    System.out.println("___________________________________");
            System.out.println(" Program has now ended.");
                }
            } 
            else {
                System.out.println("___________________________________");
             System.out.println(" Formatting error, student's position must be integer > 0.");}
        }




        if (menuOption.matches("5")) { //menu option 5 is to quit program.
            System.out.println("___________________________________");
            System.out.println(" Program has been quit.");
            System.exit(1); 

        } 
    }

}