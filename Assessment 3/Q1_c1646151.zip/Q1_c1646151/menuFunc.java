/*
 * Name: Charles Read
 * Student Number: c1646151
 */

import java.util.ArrayList; //array listed used.
import java.io.*;
import java.util.Scanner;
public class menuFunc {

    private ArrayList < studentEntry > entryArray;

    public menuFunc() {
        entryArray = new ArrayList < studentEntry > ();
    }

    //function adds values into the arrayList. 
    public void add(String studentNum, String studentName, String courseID, String courseName, String houseNum, String streetName, String townName, String postcode) {
        entryArray.add(new studentEntry(studentName, studentNum, courseID, courseName, houseNum, streetName, townName, postcode));

    }

    //function reads and displays given file.
    public void Read(String file) { 
        try {
            FileReader reader = new FileReader(file);
            BufferedReader in = new BufferedReader(reader);
            String tempStr;
            while ((tempStr = in.readLine()) != null) { //while loop runs until there is no more data to read.
                System.out.println(new StringBuffer(tempStr)); //outputs student entries by line.
            } in .close(); 
        } 

        //Missing file exception handler.
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended due to a file not found.");
            System.exit(1); 
        } 

        catch (IOException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1);
        }
    }
    
    //function writes entry from with the arrayList data.
    public void Write(String file) { 
        try {
            FileWriter writer = new FileWriter(file, true); //stores current student entries.
            PrintWriter output = new PrintWriter(writer);
            for (int i = 0; i < entryArray.size(); i++) { //loop runs arratList entries.
                output.println(entryArray.get(i) + " "); //writes data to chosen file.

            }
            output.close();
        } 
        catch (Exception e) { 
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1);
        }
    }


    //function rewrites file without chosen student.
    public void deleteEntry(String file, int position) { 
        try {
            Writer output = new BufferedWriter(new FileWriter(file, true));  //stores current student entries.
            FileReader reader = new FileReader(file);
            BufferedReader in = new BufferedReader(reader);
            int c = 0; //count is parallel to the position number.
            String tempStr;

            while ((tempStr = in .readLine()) != null) { //while loop runs until there is no more data to read.
                c++; //increment  by 1.

                if (c != position) {
                    PrintWriter writer = new PrintWriter(file);
                    writer.print(""); //clears whole file.
                    writer.close(); 
                    output.write(tempStr + "\n"); //recreates file excluding chosen student entry.
                }

            } in .close(); 

            output.close(); 
        } 

        //Missing file exception handler.
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended due to a file not found.");

            System.exit(1); 
}
        catch (IOException e) { 
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1); 
        }
    }
}