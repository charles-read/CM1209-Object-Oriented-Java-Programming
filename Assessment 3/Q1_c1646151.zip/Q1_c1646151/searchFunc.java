/*
 * Name: Charles Read
 * Student Number: c1646151
 */


import java.util.ArrayList;
import java.io.*;

public class searchFunc {

//function compares and matches course names with user given course name.
public void courseSearch(String file, String courseInput) { 
        try {
            FileReader reader = new FileReader(file);
            BufferedReader in = new BufferedReader(reader);
            String tempStr;

            while ((tempStr = in.readLine()) != null) { //while loop runs until there is no more data to read.
                String a[] = tempStr.split(","); //places values in array.
                String courseName1 = a[3]; //position 3 is assigned to courseName1.

                //formats both input and course names so they can be compared fairly. Removes lower case and spaces.
                courseName1 = courseName1.toLowerCase(); 
                courseName1 = courseName1.replaceAll(" ", ""); 
                courseInput = courseInput.toLowerCase(); 
                courseInput = courseInput.replaceAll(" ", ""); 

                //checks for a match between the formatted values.
                if (courseName1.matches(".*" + courseInput + ".*")) { 
                    System.out.println(new StringBuffer(tempStr)); //data displayed if match found.
                }

            } in .close(); 
        } 

        //Missing file exception handler.
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended due to a file not found.");

            System.exit(1);
        } 

        catch (IOException e) { 
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1); 
        }
    }


    //function compares and matches address substring to user substring.
    public void addressSearch(String file, String addressName) { 
        try {
            FileReader reader = new FileReader(file);
            BufferedReader in = new BufferedReader(reader);
            String tempStr; //string used to take temp line entry.
            while ((tempStr = in .readLine()) != null) { //while loop runs until there is no more data to read.
                String a[] = tempStr.split(","); //places individual values in array.

                //places corresponding values into arrayList positions.
                String houseNum1 = a[4]; 
                String streetName1 = a[5]; 
                String townName1 = a[6]; 
                String postcode1 = a[7]; 

                //formats address values so they can be compared fairly. Removes lower case and spaces.
                houseNum1 = houseNum1.toLowerCase(); 
                houseNum1 = houseNum1.replaceAll(" ", ""); 
                streetName1 = streetName1.toLowerCase(); 
                streetName1 = streetName1.replaceAll(" ", ""); 
                townName1 = townName1.toLowerCase(); 
                townName1 = townName1.replaceAll(" ", ""); 
                postcode1 = postcode1.toLowerCase(); 
                postcode1 = postcode1.replaceAll(" ", ""); 
                addressName = addressName.toLowerCase(); 
                addressName = addressName.replaceAll(" ", ""); 

                //checks if any of the address substrings matches user input.
                if (houseNum1.matches(".*" + addressName + ".*") || 
                streetName1.matches(".*" + addressName + ".*") || 
                townName1.matches(".*" + addressName + ".*") || 
                postcode1.matches(".*" + addressName + ".*")) { 
                    System.out.println(new StringBuffer(tempStr)); //data displayed if match found.
                }
            } in .close();
        } 

        //Missing file exception handler.
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended due to a file not found.");

            System.exit(1); 
        } 

        catch (IOException e) { 
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1); 
        }
    }



        //function displays students within given range.
    public void viewRange(String file, int rangeStart, int rangeEnd) {
        try {
            FileReader reader = new FileReader(file);
            BufferedReader in = new BufferedReader(reader);
            String tempStr; //string used to take temp line entry.
            int c = 0; //count is parallel to the entry position.
            while ((tempStr = in.readLine()) != null) { ///while loop runs until there is no more data to read.
                c++; //Increment by 1.
                if ((rangeStart <= c) && (c <= rangeEnd)) { //if in range
                    System.out.println(new StringBuffer(tempStr)); //data displayed if match found.
                }

            } in .close();
        } 
        //Missing file exception handler.
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended due to a file not found.");

            System.exit(1);

        } 
        catch (IOException e) { 
            System.out.println(e);
            System.out.println("___________________________________");
            System.out.println(" Program has been ended.");

            System.exit(1);
        }
    }
}