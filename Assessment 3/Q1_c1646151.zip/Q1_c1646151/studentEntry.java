/*
 * Name: Charles Read
 * Student Number: c1646151
 */

class studentEntry {

    private String studentName;
    private String studentNum;
    private String courseName;
    private String courseID;
    private String houseNum;
    private String streetName;
    private String townName;
    private String postcode;


    //takes values and assigns them to variables.
    public studentEntry(String inSNumber, String inName, String inCourseID, String inCourseName, String inHouseNO, String inStreetName, String inTown, String inPostcode) {
        studentName = inName;
        studentNum = inSNumber;
        courseName = inCourseName;
        courseID = inCourseID;
        houseNum = inHouseNO ;
        streetName = inStreetName ;
        townName = inTown ;
        postcode = inPostcode ;
    }

    public String outputString( ) {
        return (""+studentName+"," +studentNum+ "," +courseID+ "," +courseName+ "," +houseNum+ "," +streetName+ "," +townName+ ","+postcode);
    }
}