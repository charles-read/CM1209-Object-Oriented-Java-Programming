/*
 * Name: Charles Read
 * Student Number: c1646151
 */

import java.util.Scanner;
public class scanner{ //standalone scanner class to be called throughout program for user inputs.
    Scanner in;
    
public scanner() {
    in = new Scanner(System.in);
}
public String readInput( String readInput ) {
    System.out.print(readInput); //retrieves user input.
    String scanInput = in.nextLine(); 

    return scanInput; //returns input data.
   }
}